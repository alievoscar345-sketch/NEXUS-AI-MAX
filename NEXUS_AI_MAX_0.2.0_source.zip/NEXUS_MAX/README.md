# NEXUS AI MAX — Android starter 0.2.0

Phone-first Android chat starter configured for AnyModel and the model ID shown in the user's provider screenshot: `cc/claude-fable-5-2`.

## Included in this starter
- Native Android chat UI built with Kotlin and Jetpack Compose.
- OpenAI-compatible Chat Completions request to `https://anymodel.org/v1/chat/completions`.
- Configurable base URL, model ID and API key.
- Recent conversation context in memory and basic API error reporting.

## Not implemented yet
Persistent memory, web search, autonomous tool execution, background tasks, voice, streaming, server-side secret management, and benchmark testing. Do not treat these as existing features.

## Build
The GitHub Actions workflow builds a debug APK using JDK 17 and Gradle 8.9. Android SDK 35 is installed by the workflow. The source has not been compiled or device-tested in this environment; the first cloud build is the validation step.

## API settings
- Base URL: `https://anymodel.org/v1`
- Model ID: `cc/claude-fable-5-2`
- Endpoint: `/chat/completions`

Enter your own API key in the app's API SETTINGS. Never commit the key to this repository. This prototype keeps the key in process memory only; after app restart, enter it again. A production release should use a secured backend proxy rather than embedding a provider key in a public mobile app.
